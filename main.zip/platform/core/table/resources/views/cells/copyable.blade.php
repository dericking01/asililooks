<x-core::copy
    :copyableState="$copyableState"
    :copyableAction="$copyableAction"
    :copyableMessage="$copyableMessage"
    :copyablePositionClass="$copyablePositionClass"
/>
