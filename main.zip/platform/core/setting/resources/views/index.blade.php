@extends(BaseHelper::getAdminMasterLayoutTemplate())

@section('content')
    <x-core::panel-section id="settings" />
@stop
